/*
	
*/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#define TAM 500



void pause(void);
void limpar(void);
void writeln(const char* msg);
void read(char* msg);

FILE* fileLeitura(FILE *arq, char end[], char endOut[]);
void mostrar(FILE* arq1, FILE* arq2, char end1[], char end2[]);
void bl(void);
void line(void);

int contarCaractere(char * texto);

int main(void){
	
	
	FILE *arq1, *arq2;
	
	//caminho dos arquivos
	char pasta1[] = "..\\pasta1\\dados1.txt";
	char pasta2[] = "..\\pasta2\\dados2.txt";
	char pasta3[] = "..\\pasta3\\dados3.txt";
	
	arq1 = fileLeitura(arq1, pasta1, pasta2);
	mostrar(arq1, arq2, pasta1, pasta2);
	
	printf("Aperte [ENTER] para sair!\n");
	
	pause();
}

void limpar(void){
	system("cls");
}
void line(void){
	printf("==========================================================================\n");
}
void bl(void){
	printf("\n");
}

void mostrar(FILE* arq1, FILE* arq2, char end1[], char end2[]){
	
	char *texto1, *texto2;
	int i;
	
	texto1 = (char*) calloc(TAM, sizeof(texto1));
	texto2 = (char*) calloc(TAM, sizeof(texto2));
	
	
	
	arq1 = fopen(end1, "r");
	arq2 = fopen(end2, "r");
	
	if(arq1 == NULL && arq2 == NULL){
		writeln("Erro ao ler arquivo txt!");
		exit(1);
	}
	
	
	writeln("	LETRAS EM MINUSCULO - PASTA 1");
	bl();
	
	line();
	while((fgets(texto1, sizeof(texto1), arq1)) != NULL){
		printf("%s", texto1);	
	}
	line();
	pause();
	
	limpar();
	writeln("	LETRAS EM MAIUSCULO - PASTA 2");
	line();
	while((fgets(texto2, sizeof(texto2), arq2)) != NULL){

		printf("%s", texto2);	
	}
	line();
	
}

FILE* fileLeitura(FILE *arq, char end[], char endOut[]){
	FILE *arq1;
	
	char *texto;
	
	texto = (char*) calloc(TAM, sizeof(char));
	
	arq = fopen(end, "r");
	arq1 = fopen(endOut, "a");
	
	if(arq == NULL && arq1 == NULL){
		writeln("Erro, de leitura!");
		exit(1);
	}
	

	while((fgets(texto, sizeof(texto), arq)) != NULL){
		strupr(texto);
		fprintf(arq1, "%s", texto);	
	}
	
	
	fclose(arq);
	fclose(arq1);
	
	
}

void pause(void){
	getch();
}

void read(char* msg){
	fflush(stdin);
	gets(msg);
}

void writeln(const char* msg){
	printf("%s\n", msg);
}
