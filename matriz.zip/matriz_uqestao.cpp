/*
	[ALUNO - MANOEL VITOR ]
	[PROFESSORA - LAIS FARIAS ALVES]
	[1� SEMESTRE DE AN�LISE E DESENVOLVIMENTO DE SISTEMA.]
	[AULA - ALGORITMOS E PROGRAMA��O]
	[IFBA - CAMPUS IREC�]
	
	
	Quest�o - Fa�a um programa que o usu�rio preencha uma matriz 4x4,
	Calcule a transporta dessa matriz em um procedimento.
	
	Imprima a matriz de acordo com a linha e coluna.

*/
//================================================================ BIBLIOTECAS DA LINGUAGEM C ================================================================//
#include <stdio.h>   
#include <stdlib.h>
#include <conio.h>

//================================================================ CONSTANTES LINHA E COLUNA =================================================================//
#define LINHA 4
#define COLUNA 4


//=============================================================== PROCEDIMENTO - INSTANCIANDO/CRIANDO UM PROT�TIPO DO MEU PROCEDIMENTO =======================//
void calcular_matriz(int i, int j); 

//==============================================================  VARIAVEIS GLOBAIS ==========================================================================//
int matriz[LINHA][COLUNA], transporta[LINHA][COLUNA];

//============================================================== FUNCAO MAIN - fun��o principal da linguagem C =================================================================================//

int main(){
	
	int i, j, line, row;

	
	for(i = 0; i < LINHA; i++){
		
		for(j = 0; j < COLUNA; j++){
			
			printf("\n\t[LINHA  ]: [%d]\n", i);
			printf("\n\t[COLUNA ]: [%d]\n", j);
			printf("\n\tDigite um valor: \n");
			scanf("%d", &matriz[i][j]);
			
		}
		
	}
	
	calcular_matriz(i, j);
	
	getch();
	return 0;

}


void  calcular_matriz(int i, int j){
	
	
	for(i = 0; i < LINHA; i++){
		for(j = 0; j < COLUNA; j++){
			
			transporta[i][j] = matriz[j][i];
			
		}
	}
	
	
	printf("\n\t====== MATRIZ NORMAL: =======================\n");
	
	for(i = 0; i < LINHA; i++){
		
		for(j = 0; j < COLUNA; j++){
			
			printf("\t[%d]", transporta[i][j]);
		}
		
		printf("\n\n");
	}

		printf("\n\t====== MATRIZ TRANSPORTA: =======================\n");
	
	for(i = 0; i < LINHA; i++){
		
		for(j = 0; j < COLUNA; j++){
			
			printf("\t[%d]", matriz[i][j]);
		}
		
		printf("\n\n");
	}
	
	getch();
}
