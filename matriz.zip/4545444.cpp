
/*



Fa�a um programa em que o usuario, digite dois valores e depous pe�a para ele escolha qual opera��o deseja realizar.
soma, subtra��o, divis�o e multiplica��o.
Os calculos  deve, ser feitos com fun��o.

-----------------------------------------------------------------------

fa� um programa que o us�ario preenche uma matriz 4x4.
 calcule a transporta dessa matriz em um procedimento
 
 imprima a matriz de acordo com a linhha e coluna





*/



#include <stdio.h>
#include <stdlib.h>
#include <conio.h>


int somar(int x, int y);
int subtracao(int x, int y);
int multiplicacao(int x, int y);
int divisao(int x, int y);

int main(){
	
	int x, y, r, opc;
	
	printf("\nDigite um valor para x:\n");
	scanf("%d", &x);
	
	printf("\nDigite um valor para y:\n");
	scanf("%d", &y);
	


	system("cls");
	printf("\nDigite uma das opcoes\n");
	printf("\n\t[1] -  SOMAR\n");
	printf("\n\t[2] -  SUBTRAIR\n");
	printf("\n\t[3] -  MULTIPLICAR\n");
	printf("\n\t[4] -  DIVIDIR\n");
	scanf("%d", &opc);

	switch(opc){
		case 1:
			 
			r = somar(x, y);
			printf("\n\tValor de x foi: %d \t Valor de y foi: %d\n", x, y );
			printf("\n SOMAR \n");
			printf("\n\tResultado : %d\n", r);
			getch();
				
		break;
			
		case 2:
			  
			r = subtracao(x, y);
			printf("\n\tValor de x foi: %d \t Valor de y foi: %d\n", x, y );
			printf("\n SUBTRACAO \n");
			printf("\n\tResultado : %d\n", r);
			getch();
			
		break;
			
		case 3:
			  
			r = multiplicacao(x, y);
			printf("\n\tValor de x foi: %d \t Valor de y foi: %d\n", x, y );
			printf("\n MULTIPLICACAO \n");
			printf("\n\tResultado : %d\n", r);
			getch();
				
		break;
			
		case 4:
			r = divisao(x, y);
			printf("\n\tValor de x foi: %d \t Valor de y foi: %d\n", x, y );	 
			printf("\n DIVISAO \n");
			printf("\n\tResultado : %d\n", r );
			getch();
				
		break;
	}
	
 	
 	printf("\nEncerrando.........\n");
	getch();
	return 0;
}

int somar(int x, int y){
	
	return x+y; 
	
}

int subtracao(int x, int y){
	return x-y;
}

int multiplicacao(int x, int y){
	return x*y;
}
int divisao(int x, int y){
	return x/y;
}
